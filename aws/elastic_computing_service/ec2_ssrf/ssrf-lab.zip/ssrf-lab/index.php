<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="./static/bootstrap.css">
    <title>SSRF Lab</title>
  </head>
  <body>
  <?php
    error_reporting(0);
    function curl($url){
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, $url);
      curl_setopt($ch, CURLOPT_HEADER, 0);
      curl_exec($ch);
      curl_close($ch);
    }
  ?>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="/">SSRF Lab</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor03" aria-controls="navbarColor03" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    </nav>
    <div class="container">
      <div class="jumbotron">
          <h2 class="text-center">SSRF 测试靶场</2>
      </div>
      <div class="row">
        <div class="col-md-12">
          <form method="POST">
            <div class="form-group">
              <input class="form-control form-control-lg" type="text" placeholder="输入一个网站" name="url">
            </div>
              <button type="submit" class="btn btn-primary" style="display:block;margin:0 auto">提交</button>
          </form>
        </div>
      </div>

      <hr class="my-4">
      <?php
        $url = $_POST['url'];
        if($url){
          echo "<b>".$url." 的内容如下：</b><br><br>";
          echo "<pre>";
          curl($url);
          echo "</pre>";
        }
      ?>
    </div>
    <script src="./static/jquery.min.js"></script>
    <script src="./static/bootstrap.bundle.min.js"></script>
    <!-- Code By https://github.com/sqlsec/ssrf-vuls/tree/main/172.72.23.21-SSRF -->
  </body>
</html>

